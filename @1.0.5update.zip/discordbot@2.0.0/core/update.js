const fs = require("fs");
const path = require("path");
const https = require("https");
const { execFile } = require("child_process");


const SYSTEM_DIR = path.resolve(__dirname, "..");

const UPDATE_DIR = path.join(
    SYSTEM_DIR,
    "updates"
);


const VERSION_FILE = path.join(
    SYSTEM_DIR,
    "version.json"
);


// GitHub updates folder
const GITHUB_UPDATES =
"https://api.github.com/repos/greenteamnetwork/discordbot/contents/updates";



// -------------------------
// Version
// -------------------------

function getCurrentVersion() {

    if (!fs.existsSync(VERSION_FILE)) {

        return "0.0.0";

    }


    return JSON.parse(
        fs.readFileSync(
            VERSION_FILE,
            "utf8"
        )
    ).version;

}



function saveVersion(version) {

    fs.writeFileSync(
        VERSION_FILE,

        JSON.stringify(
            {
                version: version
            },

            null,
            4
        )

    );

}



// -------------------------
// Version compare
// -------------------------

function compareVersions(a,b) {

    const aa =
        a.split(".")
        .map(Number);

    const bb =
        b.split(".")
        .map(Number);


    for (
        let i = 0;
        i < 3;
        i++
    ) {

        if ((aa[i] || 0) > (bb[i] || 0))
            return 1;


        if ((aa[i] || 0) < (bb[i] || 0))
            return -1;

    }


    return 0;

}



// -------------------------
// GitHub
// -------------------------

function getGithubUpdates(callback) {


https.get(

    GITHUB_UPDATES,

    {
        headers:{
            "User-Agent":
            "DiscordBotSystem"
        }
    },


    response => {


        let data="";


        response.on(
            "data",
            chunk =>
            data += chunk
        );


        response.on(
            "end",

            ()=>{


                try {


                    const files =
                        JSON.parse(data);



                    const updates =
                    files.filter(file => {


                        return (
                            file.name.startsWith("@")
                            &&
                            file.name.endsWith("update.zip")
                        );


                    });



                    callback(updates);



                }

                catch {

                    console.log(
                        "Could not read updates."
                    );

                }


            }

        );


    }

)

.on(
"error",
error=>{

    console.log(
        "GitHub error:",
        error.message
    );

});

}



// -------------------------
// Download
// -------------------------

function download(url,destination,callback){


const file =
fs.createWriteStream(destination);



https.get(

url,

response=>{


response.pipe(file);



file.on(
"finish",
()=>{

file.close(callback);

});


}

);


}



// -------------------------
// Changelog
// -------------------------

function showChanges(folder){


const log =
path.join(
folder,
"changelog.json"
);


if (!fs.existsSync(log)) {

    console.log(
        "No changelog found."
    );

    return;

}



const data =
JSON.parse(
fs.readFileSync(
log,
"utf8"
)
);



console.log(
"\nWhat's new:"
);



if(data.added){

console.log("\nAdded:");

data.added.forEach(x=>
console.log("+ "+x)
);

}



if(data.changed){

console.log("\nChanged:");

data.changed.forEach(x=>
console.log("* "+x)
);

}



if(data.fixed){

console.log("\nFixed:");

data.fixed.forEach(x=>
console.log("- "+x)
);

}


}



// -------------------------
// Install
// -------------------------

function installUpdate(zip){


console.log(
"Installing:",
zip
);


// Placeholder
// ZIP extraction can be added here


const version =
zip
.replace("@","")
.replace("update.zip","");


saveVersion(version);



console.log(
"Updated to",
version
);


}



// -------------------------
// Main Update
// -------------------------

function update(){


const current =
getCurrentVersion();



console.log(
"Current version:",
current
);



console.log(
"Checking GitHub updates..."
);



getGithubUpdates(
updates=>{


if(updates.length===0){

console.log(
"No updates found."
);

return;

}



let newest=null;



updates.forEach(file=>{


const version =
file.name
.replace("@","")
.replace("update.zip","");



if(
compareVersions(
version,
current
) > 0
){

newest=file;

}


});



if(!newest){

console.log(
"You are up to date."
);

return;

}



console.log(
"New update:",
newest.name
);



console.log(
"Download/install starting..."
);



// later:
// download newest.download_url


installUpdate(
newest.name
);



}

);


}



module.exports={
    update
};
