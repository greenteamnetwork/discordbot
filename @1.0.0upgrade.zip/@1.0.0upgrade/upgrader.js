const fs = require("fs");
const path = require("path");
const https = require("https");
const os = require("os");
const { execSync } = require("child_process");


const ROOT =
    path.resolve(
        __dirname,
        ".."
    );


const TEMP_ZIP =
    path.join(
        os.tmpdir(),
        "discordbotsystem-upgrade.zip"
    );


const TEMP_FOLDER =
    path.join(
        os.tmpdir(),
        "discordbotsystem-upgrade"
    );



// Change this to your upgrades branch

const OWNER =
"greenteamnetwork";

const REPO =
"discordbot";

const BRANCH =
"upgrades";


const API =
`https://api.github.com/repos/${OWNER}/${REPO}/contents/?ref=${BRANCH}`;


const RAW =
`https://github.com/${OWNER}/${REPO}/raw/refs/heads/${BRANCH}/`;



// -------------------------
// Version compare
// -------------------------

function compare(a,b){

const x =
a.split(".").map(Number);

const y =
b.split(".").map(Number);


for(let i=0;i<3;i++){

if((x[i]||0)>(y[i]||0))
return 1;


if((x[i]||0)<(y[i]||0))
return -1;

}

return 0;

}



// -------------------------
// Download
// -------------------------

function download(url,file,done){

const output =
fs.createWriteStream(file);


https.get(
url,
response=>{

response.pipe(output);


output.on(
"finish",
()=>{

output.close(done);

}

);


}

);

}



// -------------------------
// Show changes
// -------------------------

function showChanges(folder){


const file =
path.join(
folder,
"changelog.json"
);



if(!fs.existsSync(file)){
return;
}



const log =
JSON.parse(
fs.readFileSync(
file,
"utf8"
)
);



console.log("\nChanges:");



if(log.added){

console.log("\nAdded:");

log.added.forEach(x=>
console.log("+ "+x)
);

}



if(log.changed){

console.log("\nChanged:");

log.changed.forEach(x=>
console.log("* "+x)
);

}



if(log.removed){

console.log("\nRemoved:");

log.removed.forEach(x=>
console.log("- "+x)
);

}


}



// -------------------------
// Install files
// -------------------------

function installFiles(source,relative=""){


for(const item of fs.readdirSync(source)){


const from =
path.join(
source,
item
);



const rel =
path.join(
relative,
item
);



if(
rel.startsWith("bots")
){

continue;

}



const to =
path.join(
ROOT,
rel
);



if(
fs.statSync(from).isDirectory()
){


if(!fs.existsSync(to)){

fs.mkdirSync(
to,
{
recursive:true
}
);

}



installFiles(
from,
rel
);


}

else{


if(
item.endsWith(".delete")
){


const remove =
to.replace(
".delete",
""
);



if(fs.existsSync(remove)){

fs.rmSync(
remove
);


console.log(
"Deleted:",
remove
);

}


continue;

}



fs.copyFileSync(
from,
to
);



console.log(
"Installed:",
rel
);


}


}


}



// -------------------------
// Install upgrade
// -------------------------

function install(zip,version){


console.log(
"Extracting upgrade..."
);



if(fs.existsSync(TEMP_FOLDER)){

fs.rmSync(
TEMP_FOLDER,
{
recursive:true,
force:true
}
);

}



fs.mkdirSync(
TEMP_FOLDER
);



execSync(
`powershell -Command "Expand-Archive -Path '${zip}' -DestinationPath '${TEMP_FOLDER}' -Force"`
);



showChanges(
TEMP_FOLDER
);



console.log(
"\nInstalling upgrade..."
);



installFiles(
TEMP_FOLDER
);



console.log(
"\nUpgrade installed:",
version
);


}



// -------------------------
// Find upgrades
// -------------------------

function getUpgrades(callback){


https.get(

API,

{
headers:{
"User-Agent":
"DiscordBotSystem"
}
},

response=>{


let data="";


response.on(
"data",
chunk=>{
data+=chunk;
}
);


response.on(
"end",
()=>{


const files =
JSON.parse(data);



callback(

files.filter(file=>

file.name.startsWith("@")

&&

file.name.endsWith(
"upgrade.zip"
)

)

);



}

);


}

);


}



// -------------------------
// Upgrade command
// -------------------------

function upgrade(version){


console.log(
"Checking upgrades..."
);



getUpgrades(
files=>{


if(!files.length){

console.log(
"No upgrades available."
);

return;

}



let chosen=null;



if(version){


chosen =
files.find(file=>

file.name.includes(
version
)

);


}
else{


chosen =
files[files.length-1];


}



if(!chosen){

console.log(
"Upgrade not found."
);

return;

}



const upgradeVersion =
chosen.name
.replace("@","")
.replace(
"upgrade.zip",
""
);



console.log(
"Installing upgrade:",
upgradeVersion
);



download(

RAW + chosen.name,

TEMP_ZIP,

()=>{


install(
TEMP_ZIP,
upgradeVersion
);


}

);


}

);


}



module.exports={
upgrade
};
