const fs = require("fs");
const path = require("path");
const https = require("https");
const os = require("os");
const { execSync } = require("child_process");


const SYSTEM_DIR = path.resolve(__dirname, "..");

const VERSION_FILE =
    path.join(
        SYSTEM_DIR,
        "version.json"
    );


const TEMP_ZIP =
    path.join(
        os.tmpdir(),
        "discordbotsystem-update.zip"
    );


const TEMP_EXTRACT =
    path.join(
        os.tmpdir(),
        "discordbotsystem-update"
    );


// GitHub

const OWNER =
    "greenteamnetwork";

const REPO =
    "discordbot";

const BRANCH =
    "updates";


const API_URL =
`https://api.github.com/repos/${OWNER}/${REPO}/contents/?ref=${BRANCH}`;


const RAW_URL =
`https://github.com/${OWNER}/${REPO}/raw/refs/heads/${BRANCH}/`;



// -------------------------
// Version
// -------------------------

function getVersion(){

    if(!fs.existsSync(VERSION_FILE)){
        return "0.0.0";
    }

    return JSON.parse(
        fs.readFileSync(
            VERSION_FILE,
            "utf8"
        )
    ).version || "0.0.0";

}



function saveVersion(version){

    fs.writeFileSync(

        VERSION_FILE,

        JSON.stringify(
            {
                version
            },
            null,
            4
        )

    );

}



// -------------------------
// Compare versions
// -------------------------

function compareVersions(a,b){

    const x =
        a.split(".").map(Number);

    const y =
        b.split(".").map(Number);


    for(let i=0;i<3;i++){

        if((x[i]||0) > (y[i]||0))
            return 1;

        if((x[i]||0) < (y[i]||0))
            return -1;

    }


    return 0;

}



// -------------------------
// GitHub updates
// -------------------------

function getUpdates(callback){


https.get(

API_URL,

{
headers:{
"User-Agent":
"DiscordBotSystem"
}
},

response=>{


let data="";


response.on(
"data",
chunk=>{
data+=chunk;
});


response.on(
"end",
()=>{


try{


const files =
JSON.parse(data);



callback(

files.filter(file=>

file.name.startsWith("@")
&&
file.name.endsWith(
"update.zip"
)

)

);



}

catch{

console.log(
"Could not read GitHub updates."
);

}


});


}

)

.on(
"error",
err=>{

console.log(
"GitHub error:",
err.message
);

});

}



// -------------------------
// Download
// -------------------------

function download(url,file,done){


const output =
fs.createWriteStream(file);



https.get(

url,

response=>{


response.pipe(output);


output.on(
"finish",
()=>{

output.close(done);

}

);


}

);


}



// -------------------------
// Changelog
// -------------------------

function showChangelog(folder){


const file =
path.join(
folder,
"changelog.json"
);



if(!fs.existsSync(file))
{
console.log(
"No changelog."
);

return;

}



const log =
JSON.parse(
fs.readFileSync(
file,
"utf8"
)
);



console.log(
"\nChanges:"
);



if(log.added){

console.log(
"\nAdded:"
);

log.added.forEach(x=>
console.log(
"+ "+x
)
);

}



if(log.changed){

console.log(
"\nChanged:"
);

log.changed.forEach(x=>
console.log(
"* "+x
)
);

}



if(log.removed){

console.log(
"\nRemoved:"
);

log.removed.forEach(x=>
console.log(
"- "+x
)
);

}


}



// -------------------------
// Merge files
// -------------------------

function copyFolder(source,target){


if(!fs.existsSync(target)){

fs.mkdirSync(
target,
{
recursive:true
}
);

}



for(const item of fs.readdirSync(source)){


const from =
path.join(
source,
item
);


const to =
path.join(
target,
item
);



// protect bots

if(
path.relative(
SYSTEM_DIR,
to
)
.startsWith(
"bots"
)
){

continue;

}



if(
fs.statSync(from).isDirectory()
){

copyFolder(
from,
to
);

}

else{


fs.copyFileSync(
from,
to
);


console.log(
"Updated:",
path.relative(
SYSTEM_DIR,
to
)
);


}


}


}



// -------------------------
// Install
// -------------------------

function install(zip,version){


console.log(
"\nExtracting update..."
);



if(fs.existsSync(TEMP_EXTRACT)){

fs.rmSync(
TEMP_EXTRACT,
{
recursive:true
}
);

}



fs.mkdirSync(
TEMP_EXTRACT
);



execSync(

`powershell -Command "Expand-Archive -Path '${zip}' -DestinationPath '${TEMP_EXTRACT}' -Force"`

);



showChangelog(
TEMP_EXTRACT
);



console.log(
"\nInstalling files..."
);



copyFolder(
TEMP_EXTRACT,
SYSTEM_DIR
);



const updateScript =
path.join(
TEMP_EXTRACT,
"update.js"
);



if(fs.existsSync(updateScript)){


console.log(
"Running update script..."
);


require(updateScript);


}



saveVersion(
version
);



console.log(
"\nUpdate complete."
);

console.log(
"Version:",
version
);



}



// -------------------------
// Main
// -------------------------

function update(){


const current =
getVersion();



console.log(
"Current version:",
current
);


console.log(
"Checking updates..."
);



getUpdates(
updates=>{


let newest=null;



for(const file of updates){


const version =
file.name
.replace("@","")
.replace(
"update.zip",
""
);



if(
compareVersions(
version,
current
)>0
){

if(
!newest ||
compareVersions(
version,
newest.version
)>0
){

newest={
file,
version
};

}

}


}



if(!newest){

console.log(
"No updates available."
);

return;

}



console.log(
"New update:",
newest.version
);



console.log(
"Downloading update..."
);



download(

RAW_URL + newest.file.name,

TEMP_ZIP,

()=>{


install(
TEMP_ZIP,
newest.version
);


}

);


}

);


}



module.exports={
update
};
