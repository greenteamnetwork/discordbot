const fs = require("fs");
const path = require("path");

const SUPPORT_FILE = path.join(
    __dirname,
    "support.json"
);


// Load support.json
function loadSupport() {

    if (!fs.existsSync(SUPPORT_FILE)) {

        return {
            commands: {}
        };

    }


    try {

        return JSON.parse(
            fs.readFileSync(
                SUPPORT_FILE,
                "utf8"
            )
        );


    } catch (err) {

        console.error(
            "Failed to load support.json"
        );


        return {
            commands: {}
        };

    }

}


// Check if command extension is supported
function isCommandSupported(extension) {


    const support = loadSupport();



    // If commands section does not exist
    if (!support.commands) {

        return false;

    }



    // If extension is not listed
    if (!Object.prototype.hasOwnProperty.call(
        support.commands,
        extension
    )) {

        return false;

    }



    // Only true allows support
    return support.commands[extension] === true;

}



// Return supported extensions
function getSupportedCommands() {


    const support =
        loadSupport();



    if (!support.commands) {

        return [];

    }



    return Object.keys(
        support.commands
    )
    .filter(
        ext =>
        support.commands[ext] === true
    );

}



module.exports = {

    isCommandSupported,

    getSupportedCommands

};
