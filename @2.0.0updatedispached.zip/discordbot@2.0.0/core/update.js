const fs = require("fs");
const path = require("path");
const https = require("https");


const SYSTEM_DIR = path.resolve(__dirname, "..");

const VERSION_FILE = path.join(
    SYSTEM_DIR,
    "version.json"
);


const TEMP_DIR = path.join(
    SYSTEM_DIR,
    "updates"
);


// GitHub settings

const OWNER = "greenteamnetwork";
const REPO = "discordbot";

const UPDATE_BRANCH = "updates";

const GITHUB_API =
`https://api.github.com/repos/${OWNER}/${REPO}/contents/?ref=${UPDATE_BRANCH}`;


const RAW_URL =
`https://github.com/${OWNER}/${REPO}/raw/refs/heads/${UPDATE_BRANCH}/`;



// -------------------------
// Version
// -------------------------

function getCurrentVersion() {

    if (!fs.existsSync(VERSION_FILE)) {

        return "0.0.0";

    }


    const data =
        JSON.parse(
            fs.readFileSync(
                VERSION_FILE,
                "utf8"
            )
        );


    return data.version || "0.0.0";

}



function saveVersion(version) {


    fs.writeFileSync(

        VERSION_FILE,

        JSON.stringify(
            {
                version: version
            },

            null,
            4
        )

    );

}



// -------------------------
// Version compare
// -------------------------

function compareVersions(a, b) {


    const x =
        a.split(".").map(Number);


    const y =
        b.split(".").map(Number);



    for (let i = 0; i < 3; i++) {


        if ((x[i] || 0) > (y[i] || 0)) {

            return 1;

        }


        if ((x[i] || 0) < (y[i] || 0)) {

            return -1;

        }

    }


    return 0;

}



// -------------------------
// Get GitHub updates
// -------------------------

function getUpdates(callback) {


https.get(

    GITHUB_API,

    {

        headers: {
            "User-Agent":
            "DiscordBotSystem"
        }

    },


    response => {


        let data = "";


        response.on(
            "data",
            chunk => {

                data += chunk;

            }
        );



        response.on(
            "end",
            () => {


                try {


                    const files =
                        JSON.parse(data);



                    const updates =
                        files.filter(file => {


                            return (

                                file.type === "file"

                                &&

                                file.name.startsWith("@")

                                &&

                                file.name.endsWith(
                                    "update.zip"
                                )

                            );


                        });



                    callback(updates);



                }

                catch(error) {


                    console.log(
                        "GitHub response:"
                    );


                    console.log(data);


                    console.log(
                        "Could not read updates."
                    );


                }


            }
        );


    }

)

.on(
    "error",
    error => {

        console.log(
            "GitHub error:",
            error.message
        );

    }
);


}



// -------------------------
// Download
// -------------------------

function downloadFile(url, destination, callback) {


const file =
fs.createWriteStream(
    destination
);



https.get(

    url,

    response => {


        response.pipe(file);



        file.on(
            "finish",
            () => {


                file.close(
                    callback
                );


            }
        );


    }

)

.on(
"error",
error => {


    fs.unlink(
        destination,
        ()=>{}
    );


    console.log(
        "Download failed:",
        error.message
    );


});


}



// -------------------------
// Install
// -------------------------

function installUpdate(file) {


    const version =
        file.name
        .replace("@", "")
        .replace(
            "update.zip",
            ""
        );



    console.log(
        "Installing:",
        file.name
    );


    /*
       ZIP extraction goes here.

       Later:
       - extract zip
       - run included update.js
       - replace system files
       - protect bots folder
    */


    saveVersion(version);



    console.log(
        "Updated to:",
        version
    );


}



// -------------------------
// Main update command
// -------------------------

function update() {


    const current =
        getCurrentVersion();



    console.log(
        "Current version:",
        current
    );



    console.log(
        "Checking GitHub updates..."
    );



    getUpdates(
        updates => {


            if (updates.length === 0) {


                console.log(
                    "No updates found."
                );


                return;

            }



            let newest = null;



            updates.forEach(file => {


                const version =
                    file.name
                    .replace("@", "")
                    .replace(
                        "update.zip",
                        ""
                    );



                if (
                    compareVersions(
                        version,
                        current
                    ) > 0
                ) {


                    if (
                        !newest ||

                        compareVersions(
                            version,
                            newest.version
                        ) > 0

                    ) {


                        newest = {

                            file: file,

                            version: version

                        };


                    }


                }


            });



            if (!newest) {


                console.log(
                    "You are up to date."
                );


                return;

            }



            console.log(
                "New update found:",
                newest.file.name
            );



            const url =
                RAW_URL +
                newest.file.name;



            console.log(
                "Downloading:"
            );


            console.log(
                url
            );



            if (!fs.existsSync(TEMP_DIR)) {

                fs.mkdirSync(
                    TEMP_DIR,
                    {
                        recursive:true
                    }
                );

            }



            const save =
                path.join(
                    TEMP_DIR,
                    newest.file.name
                );



            downloadFile(

                url,

                save,

                ()=>{


                    console.log(
                        "Download complete."
                    );


                    installUpdate(
                        newest.file
                    );


                }

            );


        }

    );


}



module.exports = {
    update
};
