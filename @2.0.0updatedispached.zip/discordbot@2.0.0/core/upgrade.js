const fs = require("fs");
const path = require("path");
const https = require("https");


const SYSTEM_DIR = path.resolve(__dirname, "..");

const UPGRADE_DIR = path.join(
    SYSTEM_DIR,
    "upgrades"
);


// GitHub upgrades folder

const GITHUB_UPGRADES =
"https://api.github.com/repos/greenteamnetwork/discordbot/contents/upgrades";



// Get installed upgrades

function getInstalledUpgrades() {

    const file =
        path.join(
            SYSTEM_DIR,
            "upgrades.json"
        );


    if (!fs.existsSync(file)) {

        return [];

    }


    return JSON.parse(
        fs.readFileSync(
            file,
            "utf8"
        )
    );

}



// Save installed upgrades

function saveInstalled(list) {


    fs.writeFileSync(

        path.join(
            SYSTEM_DIR,
            "upgrades.json"
        ),

        JSON.stringify(
            list,
            null,
            4
        )

    );


}



// Check GitHub

function checkUpgrades(callback) {


https.get(

GITHUB_UPGRADES,

{
    headers:{
        "User-Agent":
        "DiscordBotSystem"
    }
},


response => {


let data = "";


response.on(
"data",
chunk =>
data += chunk
);



response.on(
"end",
()=>{


try {


const files =
JSON.parse(data);



const upgrades =
files.filter(file => {


return (
file.name.startsWith("@")
&&
file.name.endsWith("upgrade.zip")
);


});



callback(upgrades);



}

catch {

console.log(
"Failed to read upgrades."
);

}



}

);



}

)

.on(
"error",
err=>{

console.log(
"Upgrade check failed:",
err.message
);

}

);


}



// Main upgrade

function upgrade(name) {


console.log(
"Checking upgrades..."
);



checkUpgrades(
upgrades=>{


if(upgrades.length === 0){

console.log(
"No upgrades available."
);

return;

}



console.log(
"\nAvailable upgrades:"
);



upgrades.forEach(
item=>{

console.log(
"-",
item.name
);

}

);



if(name){


const found =
upgrades.find(
x=>x.name.includes(name)
);



if(!found){

console.log(
"Upgrade not found."
);

return;

}



console.log(
"Selected:",
found.name
);



}
else {


console.log(
"Use: upgrade <name>"
);


}



}

);


}



module.exports = {

upgrade

};
